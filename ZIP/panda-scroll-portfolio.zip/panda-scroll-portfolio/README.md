# 😊 Mr. Panda's Psychologically Safe Portfolio 🐼

**[Live site](https://www.mr-pandas-psychologically-safe-portfolio.com/)** | **[Article](https://tympanus.net/codrops/2025/12/30/the-increasing-importance-of-psychological-safety-and-self-awareness-for-creative-work/?_thumbnail_id=107253)** | **[Tutorial](https://www.youtube.com/watch?v=zyWD2E8AHCg&feature=youtu.be)**

This repo contains code of Mr. Panda's Portfolio for a Codrops article!! It's a concept portfolio website created with [Blender](https://www.blender.org/), [Three.js](https://threejs.org/), and [Krita](https://krita.org/en/). Let's fight back against toxicity in the creative industry.

![Page screenshot](public/media/og-image.webp?raw=true "Page What")

# Credits!!! 💖

- [Intro Screen Font](https://fonts.google.com/specimen/Plus+Jakarta+Sans)
- [Notebook Paper Material](https://superhivemarket.com/products/crafty-asset-pack)
- [Dragon Reference Image](https://studycli.org/chinese-culture/chinese-dragons/)
- [Tracing Kpop Demon Hunters Image](https://media-cldnry.s-nbcnews.com/image/upload/t_fit-1000w,f_auto,q_auto:best/rockcms/2025-07/250709-Kpop-Demon-Hunters-vl-256p-ea5850.jpg)
- [Egyption Artifact Reference Image One](https://www.teacherspayteachers.com/Product/Egyptian-Artifacts-Clipart-Set-1-4283355)
- [Egyption Artifact Reference Image Two](https://media.istockphoto.com/id/1188022995/vector/egyptian-artifacts-vector-illustration-a-set-of-sacred-symbols-and-decorations-of-ancient.jpg?s=612x612&w=0&k=20&c=K0eAV0wofNJhBxAXtAZOQHHHUiiUMGUcucgx5tvIzyc=)

# Extra info

- Won [FWA of the day!](https://thefwa.com/cases/mr-pandas-psychologically-safe-portfolio).
- Won [SOTD on Awwwards!](https://www.awwwards.com/sites/mr-pandas-paper-portfolio).

## 🚀 Quick Start Setup (1-2-3 Guide)

### Prerequisites
- Node.js (v18 or higher recommended)
- npm or pnpm

### Installation & Local Development
1. **Unzip** the downloaded archive.
2. **Install Dependencies**:
   ```bash
   npm install
   ```
3. **Start Local Dev Server**:
   ```bash
   npm run dev
   ```
4. **Build for Production**:
   ```bash
   npm run build
   ```
5. **Deploy**:
   The compiled static files are generated in `dist/`. Deploy directly to Vercel, Netlify, or Surge (`npx surge dist/`).

---

## 🎨 Technology Stack
- **Three.js** / WebGL for real-time 3D camera path animations
- **Vite** for ultra-fast bundling and HMR
- **Blender & Krita** procedural 3D model assets and textures

---

## 🤝 Need Help?
- **Commercial Licensing**: [https://scriptly.store/products/panda-scroll-travel-animation-portfolio](https://scriptly.store/products/panda-scroll-travel-animation-portfolio)
- **Get Support**: [https://scriptly.store/support](https://scriptly.store/support)
- **More Templates**: [https://scriptly.store/](https://scriptly.store/)

